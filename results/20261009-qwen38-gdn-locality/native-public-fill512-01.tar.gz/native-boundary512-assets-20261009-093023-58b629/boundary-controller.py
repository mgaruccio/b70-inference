#!/usr/bin/env python3
"""Disposable controller adapter; retain the reviewed native lifecycle exactly."""
from pathlib import Path
import hashlib
import runpy

BASE_SHA = "a175671ad27ef5c4a13c4e9eacd9ca50fc1e679faee3a4fd462b9e9420ae8365"
OVERLAY_SHA = "4e786822b2045f0ebe89c67019175cac3881fe8d2af800b349104b93a1e7c469"


def adapted_main(root: Path) -> int:
    base = root / "registered-controller.py"
    timing = root / "timing"
    if hashlib.sha256(base.read_bytes()).hexdigest() != BASE_SHA:
        raise RuntimeError("reviewed native controller source mismatch")
    files = {name: hashlib.sha256((timing / name).read_bytes()).hexdigest()
             for name in ("qwen38_step_timing_overlay.py",
                          "qwen38_step_timing_patch.py", "target_boundary_control.py")}
    if files["qwen38_step_timing_overlay.py"] != OVERLAY_SHA:
        raise RuntimeError("canonical True-event timing overlay changed")
    namespace = runpy.run_path(str(base))
    main = namespace["main"]
    globals_ = main.__globals__
    original_dispatch = globals_["dispatch_512"]

    def boundary_dispatch(phase0, output, container_name):
        phase0._resolve_timing_dir = lambda _explicit: timing
        if "--chrome-call-logging" not in phase0.UNITRACE_OPTIONS:
            phase0.UNITRACE_OPTIONS = (*phase0.UNITRACE_OPTIONS, "--chrome-call-logging")
        original_append = phase0._append_instrumentation

        def append(argv, metadata, **kwargs):
            result = original_append(argv, metadata, **kwargs)
            metadata["target_boundary_control"] = {
                "scope": "development-only external target-replay visibility control",
                "installation": "same XPU worker, after canonical timing install",
                "source_files": files,
                "canonical_overlay_unchanged": True,
                "native_graph_unchanged": True,
                "events": "two private scalar complex64 public Tensor.fill_ activities plus False events, outside unchanged True pair",
                "boundary_duration": "unknown until correlated PTI device accounting",
                "per_replay_synchronization": False,
                "extra_unitrace_option": "--chrome-call-logging",
            }
            return result

        phase0._append_instrumentation = append
        return original_dispatch(phase0, output, container_name)

    globals_["dispatch_512"] = boundary_dispatch
    return main()


if __name__ == "__main__":
    raise SystemExit(adapted_main(Path(__file__).resolve().parent))
