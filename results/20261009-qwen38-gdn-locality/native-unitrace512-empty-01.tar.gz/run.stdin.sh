set -u
set -o noclobber
if test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb || test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb-controller.log; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-031337-b674cb.py); actual=${actual%% *}
if test "$actual" != 630bb80a5a076573c5df5b8b9579efca3b3b17cb46746fdc28a9ed7b10b4d7cb; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_GRAPH_CAPTURE_START\n'
timeout --signal=TERM --kill-after=65s 2330s python3 -B /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-031337-b674cb.py /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb > /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb-controller.log 2>&1
rc=$?
printf 'NATIVE_GRAPH_CAPTURE_EXIT=%s\n' "$rc"
if test -f /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb/controller-footer.json; then head -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb/controller-footer.json; else tail -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb-controller.log; fi
printf '\nREMOTE_OUTPUT=%s\n' /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-031337-b674cb
exit "$rc"
