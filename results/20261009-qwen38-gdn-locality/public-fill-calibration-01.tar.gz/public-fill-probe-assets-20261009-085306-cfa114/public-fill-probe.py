"""Public-operation visibility calibration; not a model-performance result."""
import json
import torch

stream = torch.xpu.Stream()
results = []
with torch.xpu.stream(stream):
    begin = torch.empty(1, dtype=torch.complex64, device='xpu')
    end = torch.empty(1, dtype=torch.complex64, device='xpu')
    payload = torch.zeros(4096, dtype=torch.float32, device='xpu')
    for _ in range(3):
        begin.fill_(complex(1, 2))
        payload.add_(1)
        end.fill_(complex(-1, -2))
    torch.xpu.synchronize()
    graph = torch.xpu.XPUGraph()
    with torch.xpu.graph(graph, stream=stream):
        payload.add_(1)
    torch.xpu.synchronize()
    initial = float(payload[0].item())
    for marked in (False, True):
        for index in range(3):
            a = torch.xpu.Event(enable_timing=True)
            b = torch.xpu.Event(enable_timing=True)
            if marked:
                begin.fill_(complex(1, 2))
            a.record()
            graph.replay()
            b.record()
            if marked:
                end.fill_(complex(-1, -2))
            results.append((marked, index, a, b))
    # Only deferred synchronization: none inside a measured replay.
    torch.xpu.synchronize()
    expected = initial + len(results)
    observed = payload.cpu()
    if not bool(torch.all(observed == expected)):
        raise RuntimeError('graph replay payload mismatch')
    if begin.cpu().item() != complex(1, 2) or end.cpu().item() != complex(-1, -2):
        raise RuntimeError('public fill payload mismatch')
    print(json.dumps({
        'tier': 'development',
        'purpose': 'calibrate public-operation device visibility/order, not native model E2E',
        'torch_version': torch.__version__,
        'device': torch.xpu.get_device_name(),
        'current_stream_matches': torch.xpu.current_stream() == stream,
        'marker_dtype': 'complex64', 'marker_elements': 1,
        'measured_graph_replays': len(results), 'marked_graph_replays': 3,
        'expected_marked_fill_activities': 6, 'warmup_fill_operations': 6,
        'no_per_replay_host_synchronization': True,
        'payload_initial': initial, 'payload_final': expected,
        'true_pair_samples': [
            {'marked': marked, 'index': index, 'duration_ms': a.elapsed_time(b)}
            for marked, index, a, b in results
        ],
        'device_visibility_and_order': 'requires direct PTI analysis; not asserted by this script',
    }, indent=2), flush=True)
