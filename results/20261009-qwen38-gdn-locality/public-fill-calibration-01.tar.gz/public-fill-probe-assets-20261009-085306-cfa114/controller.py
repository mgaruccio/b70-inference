from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,time,uuid

BASE=Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-boundary512-assets-20261009-074722-da0f38/registered-controller.py')
BASE_SHA='a175671ad27ef5c4a13c4e9eacd9ca50fc1e679faee3a4fd462b9e9420ae8365'
IMAGE='vllm/vllm-openai-xpu@sha256:f01e24f6c7ff01f1e0662234255a1372297d1dbd89d003cf13c8fad3eab1ba4f'
UNITRACE=Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality-harness-retry2/unitrace-install')

def main():
    if len(sys.argv)!=2:raise RuntimeError('usage: controller FRESH_OUTPUT')
    out=Path(sys.argv[1]).resolve()
    if out.exists():raise RuntimeError('fresh output required')
    out.mkdir();(out/'unitrace').mkdir()
    if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:raise RuntimeError('guard source mismatch')
    guard=runpy.run_path(str(BASE))
    name='b70fillprobe'+str(os.getpid())+uuid.uuid4().hex[:10]
    nonce=uuid.uuid4().hex
    pre=guard['kernel'](out,'pre')
    if any(x['error_lines'] for x in pre['commands'].values()):raise RuntimeError('pre-kernel guarded errors')
    guard['preconditions'](out,name)
    probe=Path(__file__).resolve().parent/'public-fill-probe.py'
    argv=['docker','run','--pull=never','--rm','--name',name,'--label','b70.fill_probe='+nonce,
          '--network','none','--ipc=host','--device','/dev/dri','--group-add','987',
          '-v','/dev/dri:/dev/dri:ro','-v',str(UNITRACE)+':/unitrace:ro',
          '-v',str(probe)+':/probe.py:ro','-v',str(out)+':/output',
          '-e','ZE_FLAT_DEVICE_HIERARCHY=COMPOSITE','-e','ZE_AFFINITY_MASK=0',
          '-e','PYTORCH_ALLOC_CONF=expandable_segments:True',
          '--entrypoint','/unitrace/bin/unitrace',IMAGE,
          '--device-timing','--chrome-kernel-logging','--chrome-device-logging','--chrome-call-logging',
          '--session',name,'--output-dir-path','/output/unitrace','/opt/venv/bin/python','-B','/probe.py']
    guard['put'](out/'probe-contract.json',{'tier':'development','purpose':'public fill visibility/order calibration; not native model E2E','argv':argv,'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'timeout_s':150,'native_model_changed':False})
    status=1;failure=None;started=time.monotonic()
    try:
        with (out/'probe.stdout').open('wb') as stdout,(out/'probe.stderr').open('wb') as stderr:
            result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=150)
        status=result.returncode
    except BaseException as exc:
        failure={'type':type(exc).__name__,'message':str(exc)}
        guard['put'](out/'probe-failure.json',failure)
    finally:
        inspection=subprocess.run(['docker','inspect',name],capture_output=True,timeout=30)
        if inspection.returncode==0:
            data=json.loads(inspection.stdout)[0]
            if data.get('Config',{}).get('Labels',{}).get('b70.fill_probe')!=nonce:
                raise RuntimeError('cleanup ownership mismatch')
            cleanup=subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=30)
            guard['put'](out/'probe-cleanup.json',{'status':cleanup.returncode,'owned_id':data['Id'],'stdout':cleanup.stdout.decode(),'stderr':cleanup.stderr.decode()})
        else:
            guard['put'](out/'probe-cleanup.json',{'status':'already_removed','inspect_returncode':inspection.returncode})
        post=guard['kernel'](out,'post')
        state=out/'post-state';state.mkdir();guard['preconditions'](state,name)
        before={x for s in pre['commands'].values() for x in s['error_lines']};after={x for s in post['commands'].values() for x in s['error_lines']}
        new=sorted(after-before)
        guard['put'](out/'kernel-post-check.json',{'status':'failed' if new else 'clear','new_guarded_error_lines':new})
        if new:status=1
    guard['put'](out/'probe-footer.json',{'status':status,'failure':failure,'elapsed_s':time.monotonic()-started})
    print(json.dumps({'status':status,'output':str(out),'elapsed_s':time.monotonic()-started}),flush=True)
    return status

if __name__=='__main__':raise SystemExit(main())
