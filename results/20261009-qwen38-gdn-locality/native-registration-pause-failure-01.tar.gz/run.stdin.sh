set -u
set -o noclobber
if test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144 || test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144-controller.log; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-043827-1c3144.py); actual=${actual%% *}
if test "$actual" != e600a1b87384629b1820ed45830bba89ad65739c0d767a026f8bf5b411c07cf8; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_GRAPH_CAPTURE_START\n'
timeout --signal=TERM --kill-after=65s 2600s python3 -B /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-043827-1c3144.py /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144 > /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144-controller.log 2>&1
rc=$?
printf 'NATIVE_GRAPH_CAPTURE_EXIT=%s\n' "$rc"
if test -f /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144/controller-footer.json; then head -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144/controller-footer.json; else tail -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144-controller.log; fi
printf '\nREMOTE_OUTPUT=%s\n' /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-043827-1c3144
exit "$rc"
