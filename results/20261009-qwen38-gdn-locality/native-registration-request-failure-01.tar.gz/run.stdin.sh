set -u
set -o noclobber
if test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e || test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e-controller.log; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-042817-060d4e.py); actual=${actual%% *}
if test "$actual" != c41de4038024862ea9c9e8000d1f6da129ba65139bb6ab7e3b9e72f58ba2cc49; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_GRAPH_CAPTURE_START\n'
timeout --signal=TERM --kill-after=65s 2600s python3 -B /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-042817-060d4e.py /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e > /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e-controller.log 2>&1
rc=$?
printf 'NATIVE_GRAPH_CAPTURE_EXIT=%s\n' "$rc"
if test -f /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e/controller-footer.json; then head -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e/controller-footer.json; else tail -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e-controller.log; fi
printf '\nREMOTE_OUTPUT=%s\n' /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-042817-060d4e
exit "$rc"
