from pathlib import Path
import subprocess, tempfile, hashlib, uuid, datetime, shlex

root=Path(tempfile.mkdtemp(prefix='b70-native-smoke-launch-'))
tag=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]
campaign='/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality'
source=Path('/tmp/native-qwen38-mtp4-smoke-controller.py')
remote=campaign+'/native-smoke-controller-'+tag+'.py'
out=campaign+'/native-smoke-'+tag
log=out+'-controller.log'
sha=hashlib.sha256(source.read_bytes()).hexdigest()
batch=root/'sftp.batch'
batch.write_text('put '+str(source)+' '+remote+'\n')
options=['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ControlMaster=no','-o','ControlPath=none','-o','ConnectTimeout=10']
cmd=['sftp','-B','512','-R','1',*options,'-b',str(batch),'inference-host']
print('LAUNCH_ARTIFACTS',root,'REMOTE_OUTPUT',out,flush=True)
r=subprocess.run(cmd,capture_output=True,timeout=75)
(root/'stage.stdout').write_bytes(r.stdout);(root/'stage.stderr').write_bytes(r.stderr)
print('SFTP_EXIT',r.returncode,flush=True)
if r.returncode:
 print(r.stderr.decode(errors='replace')[-800:],flush=True)
 raise SystemExit(r.returncode)
script=f'''set -u
set -o noclobber
if test -e {shlex.quote(out)} || test -e {shlex.quote(log)}; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum {shlex.quote(remote)})
actual=${{actual%% *}}
if test "$actual" != {shlex.quote(sha)}; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_QUALIFICATION_START\\n'
timeout --signal=TERM --kill-after=65s 2330s python3 -B {shlex.quote(remote)} {shlex.quote(out)} > {shlex.quote(log)} 2>&1
rc=$?
printf 'NATIVE_QUALIFICATION_EXIT=%s\\n' "$rc"
if test -f {shlex.quote(out+'/controller-footer.json')}; then head -c 700 {shlex.quote(out+'/controller-footer.json')}; else tail -c 700 {shlex.quote(log)}; fi
printf '\\nREMOTE_OUTPUT=%s\\n' {shlex.quote(out)}
exit "$rc"
'''
(root/'run.stdin.sh').write_text(script)
try:
 r=subprocess.run(['ssh',*options,'inference-host','bash','-s'],input=script.encode(),capture_output=True,timeout=2420)
 stdout,stderr,code=r.stdout,r.stderr,r.returncode
except subprocess.TimeoutExpired as e:
 stdout,stderr,code=e.stdout or b'',e.stderr or b'',124
(root/'run.stdout').write_bytes(stdout);(root/'run.stderr').write_bytes(stderr)
print(stdout.decode(errors='replace')[-1600:],flush=True)
print('SSH_EXIT',code,'STDERR',stderr.decode(errors='replace')[-500:],flush=True)
raise SystemExit(code)
