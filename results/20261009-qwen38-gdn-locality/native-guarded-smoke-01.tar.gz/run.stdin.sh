set -u
set -o noclobber
if test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf || test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf-controller.log; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-controller-20261009-023244-b84caf.py)
actual=${actual%% *}
if test "$actual" != 104f9f6a12dd6f8253a09bf150b41a0fb005204d9e84958e5bbcf87467646a54; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_QUALIFICATION_START\n'
timeout --signal=TERM --kill-after=65s 2330s python3 -B /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-controller-20261009-023244-b84caf.py /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf > /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf-controller.log 2>&1
rc=$?
printf 'NATIVE_QUALIFICATION_EXIT=%s\n' "$rc"
if test -f /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf/controller-footer.json; then head -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf/controller-footer.json; else tail -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf-controller.log; fi
printf '\nREMOTE_OUTPUT=%s\n' /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-smoke-20261009-023244-b84caf
exit "$rc"
