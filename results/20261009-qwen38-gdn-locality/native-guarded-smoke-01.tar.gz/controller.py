#!/usr/bin/env python3
"""Ephemeral, test-only native MTP4 smoke controller; never changes the repo."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

PHASE0 = Path("/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality-harness-retry2/run-phase0.py")
DRIVER = Path("/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20260911-qwen38-step-profile-64k/run-step-profile.py")
LONG_CLIENT = Path("/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20260909-standard/mtp4-long/qwen38_long_context_bench.py")
LAUNCHER = Path("/home/mike/inference/launchers/start-qwen38.sh")
EXPECTED_LAUNCHER_SHA256 = "63b61b16bfcdb44bb5df9e0a7b1ee0b2666101951d9229b8b263c2c42fb38de4"
EXPECTED_CLIENT_SHA256 = "a01a99b21f36ef446d220df66a4e739a02b3ab18dfe99dec8beb333719276907"
EXPECTED_BOOT_ID = "c93aea98-bb22-4cf6-879f-42d2980cb726"
EXPECTED_CPU_MAX_KHZ = "3801000"
GUARD_TIME = "2026-10-09 00:43:33"
EXPECTED_PHASE0_SHA256 = "8b908b6de7e5fbab61e60913b409e6826579bf1ae3295a280104c78b81ba59c0"
EXPECTED_DRIVER_SHA256 = "617eafda957d6c1127e3429a5b56aaa2a3f7f66f42a2c88795dc6672628e6614"
ERROR_RE = re.compile(r"mca:|machine check|hardware error|uncorrected|data.?fabric.*(?:error|sync.?flood)|watchdog.*(?:lockup|clocksource|error)|\bAER:.*(?:error|fatal)|\bxe\b.*(?:error|fault|wedged|hang)", re.I)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(argv: list[str], *, timeout: float = 30.0) -> subprocess.CompletedProcess[str]:
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True, timeout=timeout,
                          check=False)


def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def kernel_snapshot(out: Path, phase: str) -> dict[str, object]:
    """Capture bounded privileged kernel evidence; failure is a hard stop."""
    commands = {
        "dmesg": ["sudo", "-n", "timeout", "--kill-after=1s", "20s", "dmesg", "--color=never"],
        "journal": ["sudo", "-n", "timeout", "--kill-after=1s", "20s", "journalctl", "-k", "-b", "0", "--since", GUARD_TIME, "--no-pager"],
    }
    result: dict[str, object] = {"phase": phase, "guard_time": GUARD_TIME, "commands": {}}
    for label, argv in commands.items():
        try:
            completed = run(argv, timeout=25)
            text = completed.stdout
        except Exception as exc:
            raise RuntimeError(f"{phase} kernel snapshot failed for {label}: {exc}") from exc
        raw_path = out / f"kernel-{phase}-{label}.raw"
        raw_path.write_text(text, encoding="utf-8", errors="replace")
        result["commands"][label] = {
            "argv": argv, "returncode": completed.returncode,
            "raw": raw_path.name, "bytes": len(text.encode()),
            "error_lines": [line for line in text.splitlines() if ERROR_RE.search(line)] if label == "journal" else [],
        }
        if completed.returncode != 0:
            raise RuntimeError(f"{phase} kernel snapshot command failed: {label} rc={completed.returncode}")
    write(out / f"kernel-{phase}.json", result)
    return result


def assert_preconditions(out: Path, name: str) -> dict[str, object]:
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    if boot != EXPECTED_BOOT_ID:
        raise RuntimeError(f"boot id mismatch: expected {EXPECTED_BOOT_ID}, observed {boot}")
    boost = Path("/sys/devices/system/cpu/cpufreq/boost")
    if not boost.is_file() or boost.read_text().strip() != "0":
        raise RuntimeError("CPU boost is not confirmed disabled")
    caps = {}
    for cpu in range(16):
        path = Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_max_freq")
        caps[str(cpu)] = path.read_text().strip() if path.is_file() else "missing"
    if set(caps.values()) != {EXPECTED_CPU_MAX_KHZ}:
        raise RuntimeError(f"CPU caps are not all {EXPECTED_CPU_MAX_KHZ}: {caps}")
    if not LAUNCHER.is_file() or sha256(LAUNCHER) != EXPECTED_LAUNCHER_SHA256:
        raise RuntimeError("production launcher SHA256 mismatch")
    if not LONG_CLIENT.is_file() or sha256(LONG_CLIENT) != EXPECTED_CLIENT_SHA256:
        raise RuntimeError("golden long client SHA256 mismatch")
    ps = run(["docker", "ps", "--format", "{{.Names}}"], timeout=30)
    running = [line for line in ps.stdout.splitlines() if line]
    if ps.returncode != 0 or running:
        raise RuntimeError(f"competing running containers: {running}")
    existing = run(["docker", "ps", "-a", "--format", "{{.Names}}"], timeout=30)
    if existing.returncode != 0 or name in existing.stdout.splitlines():
        raise RuntimeError(f"test container name is not fresh: {name}")
    evidence = {"boot_id": boot, "boost": "0", "cpu_max_khz": caps,
                "launcher_sha256": sha256(LAUNCHER), "long_client_sha256": sha256(LONG_CLIENT),
                "running_containers": running, "container_name": name}
    write(out / "preconditions.json", evidence)
    return evidence


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: native-qwen38-mtp4-smoke-controller.py FRESH_OUTPUT_DIR")
    out = Path(sys.argv[1]).resolve()
    if out.exists():
        raise RuntimeError(f"output must be fresh: {out}")
    out.mkdir(parents=True)
    name = f"b70-qwen38-mtp4-smoke-{os.getpid()}-{uuid.uuid4().hex[:10]}"
    phase0_spec = importlib.util.spec_from_file_location("native_qwen38_phase0", PHASE0)
    if phase0_spec is None or phase0_spec.loader is None:
        raise RuntimeError(f"cannot import staged runner: {PHASE0}")
    phase0 = importlib.util.module_from_spec(phase0_spec)
    phase0_spec.loader.exec_module(phase0)
    for path, expected in [(PHASE0, EXPECTED_PHASE0_SHA256), (DRIVER, EXPECTED_DRIVER_SHA256)]:
        if not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"unchanged runner dependency hash mismatch: {path}")
    phase0.BASE_DRIVER = DRIVER
    if not hasattr(phase0, "run_on_current_host"):
        raise RuntimeError("staged runner lacks run_on_current_host")
    phase0.BASELINE_LENGTHS = (512,)
    phase0._container_name = lambda _mode: name
    original_configure = phase0._configure_benchmark
    def configure_smoke(namespace, benchmark):
        namespace["PROMPT_TOKENS"] = 512
        return original_configure(namespace, benchmark)
    phase0._configure_benchmark = configure_smoke
    native_out = out / "native"  # Existing driver creates its own fresh directory.
    write(out / "controller-contract.json", {
        "phase0": str(PHASE0), "base_driver": str(DRIVER), "long_client": str(LONG_CLIENT),
        "baseline_lengths": [512], "container_name": name,
        "timeouts_s": {"startup": 1800, "benchmark": 300, "request": 180, "control": 60, "outer": 2330},
        "contract": "native MTP4 graph-enabled 512-only qualification; inherited driver purpose text is generic; no speedup or full stability claim",
    })
    pre = kernel_snapshot(out, "pre")
    if any(item["error_lines"] for item in pre["commands"].values()):
        raise RuntimeError("precondition kernel snapshot contains guarded error lines")
    assert_preconditions(out, name)
    status = 1
    failure = None
    started = time.monotonic()
    try:
        status = int(phase0.run_on_current_host(
            "baseline", native_out, ["--startup-timeout", "1800", "--benchmark-timeout", "300",
            "--request-timeout", "180", "--control-timeout", "60", "--long-client", str(LONG_CLIENT)], None, None))
    except BaseException as exc:
        failure = {"type": type(exc).__name__, "message": str(exc)}
        write(out / "controller-failure.json", failure)
    finally:
        post = kernel_snapshot(out, "post")
        post_state = out / "post-state"
        post_state.mkdir()
        assert_preconditions(post_state, name)
        pre_lines = {line for side in pre["commands"].values() for line in side["error_lines"]}
        post_lines = {line for side in post["commands"].values() for line in side["error_lines"]}
        new_errors = sorted(post_lines - pre_lines)
        write(out / "kernel-post-check.json", {"new_guarded_error_lines": new_errors,
            "status": "failed" if new_errors else "clear"})
        if new_errors:
            status = 1
    write(out / "controller-footer.json", {"status": status, "failure": failure,
        "elapsed_s": time.monotonic() - started, "output": str(out)})
    print(json.dumps({"status": status, "output": str(out), "container_name": name}, sort_keys=True), flush=True)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
