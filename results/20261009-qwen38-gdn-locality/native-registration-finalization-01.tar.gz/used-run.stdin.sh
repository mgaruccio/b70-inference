set -u
set -o noclobber
if test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e || test -e /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e-controller.log; then echo FRESH_OUTPUT_CONFLICT; exit 1; fi
actual=$(sha256sum /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-051043-ca919e.py); actual=${actual%% *}
if test "$actual" != a175671ad27ef5c4a13c4e9eacd9ca50fc1e679faee3a4fd462b9e9420ae8365; then echo CONTROLLER_TRANSFER_HASH_MISMATCH; exit 1; fi
printf 'NATIVE_GRAPH_CAPTURE_START\n'
timeout --signal=TERM --kill-after=65s 2600s python3 -B /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-controller-20261009-051043-ca919e.py /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e > /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e-controller.log 2>&1
rc=$?
printf 'NATIVE_GRAPH_CAPTURE_EXIT=%s\n' "$rc"
if test -f /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e/controller-footer.json; then head -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e/controller-footer.json; else tail -c 700 /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e-controller.log; fi
printf '\nREMOTE_OUTPUT=%s\n' /home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality/native-unitrace512-20261009-051043-ca919e
exit "$rc"
