#!/usr/bin/env python3
"""Ephemeral graph-aware unitrace controller; test-only, never repository code."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, runpy, subprocess, sys, time, uuid
from pathlib import Path

PHASE0 = Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality-harness-retry2/run-phase0.py')
DRIVER = Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20260911-qwen38-step-profile-64k/run-step-profile.py')
CLIENT = Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20260909-standard/mtp4-long/qwen38_long_context_bench.py')
UNITRACE = Path('/home/mike/b70-evals/qwen38-b70-gptq-int4-mtp4/20261009-qwen38-gdn-locality-harness-retry2/unitrace-install')
LAUNCHER = Path('/home/mike/inference/launchers/start-qwen38.sh')
PHASE0_SHA = '8b908b6de7e5fbab61e60913b409e6826579bf1ae3295a280104c78b81ba59c0'
DRIVER_SHA = '617eafda957d6c1127e3429a5b56aaa2a3f7f66f42a2c88795dc6672628e6614'
CLIENT_SHA = 'a01a99b21f36ef446d220df66a4e739a02b3ab18dfe99dec8beb333719276907'
LAUNCHER_SHA = '63b61b16bfcdb44bb5df9e0a7b1ee0b2666101951d9229b8b263c2c42fb38de4'
BOOT_ID = 'c93aea98-bb22-4cf6-879f-42d2980cb726'
GUARD_TIME = '2026-10-09 00:43:33'
CAP_KHZ = '3801000'
POWER_CAP = Path('/sys/class/drm/card0/device/hwmon/hwmon2/power1_cap')
POWER_CAP_UW = '230000000'
SRC_SHA = '887bba6e28ce84cc0d3813ef876e24add107c318'
ERR = re.compile(r'mca:|machine check|hardware error|uncorrected|data.?fabric.*(?:error|sync.?flood)|watchdog.*(?:lockup|clocksource|error)|\bAER:.*(?:error|fatal)|\bxe\b.*(?:error|fault|wedged|hang)', re.I)

def digest(p):
    h=hashlib.sha256();
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()

def cmd(argv, timeout=30):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, check=False)

def put(p, x): p.write_text(json.dumps(x, indent=2, sort_keys=True)+'\n', encoding='utf-8')

def kernel(out, phase):
    commands={'dmesg':['sudo','-n','timeout','--kill-after=1s','20s','dmesg','--color=never'],
              'journal':['sudo','-n','timeout','--kill-after=1s','20s','journalctl','-k','-b','0','--since',GUARD_TIME,'--no-pager']}
    rec={'phase':phase,'guard_time':GUARD_TIME,'commands':{}}
    for label, argv in commands.items():
        r=cmd(argv,25); raw=out/f'kernel-{phase}-{label}.raw'; raw.write_text(r.stdout, encoding='utf-8', errors='replace')
        errors=[x for x in r.stdout.splitlines() if ERR.search(x)] if label=='journal' else []
        rec['commands'][label]={'argv':argv,'returncode':r.returncode,'raw':raw.name,'error_lines':errors}
        if r.returncode != 0: raise RuntimeError(f'{phase} kernel snapshot failed: {label} rc={r.returncode}')
    put(out/f'kernel-{phase}.json',rec); return rec

def preconditions(out, name):
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if boot != BOOT_ID: raise RuntimeError(f'boot id mismatch: {boot}')
    boost=Path('/sys/devices/system/cpu/cpufreq/boost')
    if not boost.is_file() or boost.read_text().strip() != '0': raise RuntimeError('boost is not 0')
    caps={}
    for i in range(16):
        p=Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_max_freq')
        if not p.is_file(): raise RuntimeError(f'missing cached scaling cap path: {p}')
        caps[str(i)]=p.read_text().strip()
    if set(caps.values()) != {CAP_KHZ}: raise RuntimeError(f'caps={caps}')
    if not POWER_CAP.is_file() or POWER_CAP.read_text().strip() != POWER_CAP_UW: raise RuntimeError('power cap is not 230 W')
    for p, expected in ((PHASE0,PHASE0_SHA),(DRIVER,DRIVER_SHA),(CLIENT,CLIENT_SHA),(LAUNCHER,LAUNCHER_SHA)):
        if not p.is_file() or digest(p) != expected: raise RuntimeError(f'hash mismatch: {p}')
    if not (UNITRACE/'bin/unitrace').is_file(): raise RuntimeError(f'missing installed unitrace: {UNITRACE}')
    live=cmd(['docker','ps','--format','{{.Names}}'])
    running=live.stdout.splitlines()
    if live.returncode or running: raise RuntimeError(f'container query failed or competing containers: {running}')
    all_result=cmd(['docker','ps','-a','--format','{{.Names}}'])
    all_names=all_result.stdout.splitlines()
    if all_result.returncode or name in all_names: raise RuntimeError(f'container query failed or name collision: {name}')
    put(out/'preconditions.json',{'boot_id':boot,'boost':'0','cpu_max_khz':caps,'container_name':name,
        'phase0_sha256':digest(PHASE0),'driver_sha256':digest(DRIVER),'client_sha256':digest(CLIENT),
        'launcher_sha256':digest(LAUNCHER),'unitrace_install':str(UNITRACE),'unitrace_source_commit':SRC_SHA,
        'power_cap_microwatts':'230000000','running_containers':running})

def post_pause_gpu_traces(out, baseline):
    valid = []
    for path in (out/'unitrace').glob('*.json'):
        try:
            name = str(path.relative_to(out)); size = path.stat().st_size
            if size <= baseline.get(name, 0):
                continue
            trace = json.loads(path.read_text())
            activities = trace.get('traceEvents', []) if isinstance(trace, dict) else trace
            if isinstance(activities, list) and any(isinstance(e, dict) and e.get('ph') == 'X'
                    and e.get('cat') == 'gpu_op' and isinstance(e.get('dur'), (int, float))
                    and e['dur'] > 0 for e in activities):
                valid.append({'path': name, 'bytes': size})
        except (ValueError, OSError, TypeError):
            pass
    return valid

def capture_artifact_check(phase0, out):
    status = phase0._unitrace_artifact_check(out)
    record = json.loads((out/'unitrace-artifact-check.json').read_text())
    qualified = []
    try:
        pause = json.loads((out/'startup-registration-pause.json').read_text())
        proof = json.loads((out/'producer-flush-check.json').read_text())
        if (pause['returncode'] == 0 and proof['session'] == phase0.UNITRACE_SESSION
                and proof['flush_acknowledgements']):
            current = {item['path'] for item in post_pause_gpu_traces(out, pause['trace_file_sizes'])}
            claimed = {item['path'] for item in proof['complete_activity_traces']}
            qualified = sorted(current & claimed & set(record['valid_json_trace_files']))
    except (OSError, ValueError, KeyError, TypeError):
        pass
    record['unqualified_json_trace_files'] = sorted(set(record['valid_json_trace_files']) - set(qualified))
    record['valid_json_trace_files'] = qualified
    record['scope'] = 'post-pause producer files only; complete target graph accounting still required'
    if not qualified:
        status = 1; record['status'] = 'blocked'
        record['reason'] = 'no confirmed post-pause GPU producer trace; startup files do not qualify'
    put(out/'unitrace-artifact-check.json', record)
    summary_path = out/'summary.json'
    if summary_path.is_file():
        summary = json.loads(summary_path.read_text()); summary['unitrace_artifact_check'] = record
        if status:
            summary['status'] = 'failed'
            summary.setdefault('error', {'type': 'PostPauseProducerTraceMissing', 'message': record['reason']})
        put(summary_path, summary)
    return status

def drain_and_confirm(client, out, session):
    """Observe temporal stop in the actual GPU producer, before SIGKILL cleanup."""
    marker = 'B70_GDN_LOCALITY_SUMMARY:'
    summaries = [json.loads(line.split(marker, 1)[1].strip())
                 for line in (out/'server.log').read_text(errors='replace').splitlines()
                 if marker in line]
    events = [event for summary in summaries for event in summary.get('unitrace_control_events', [])]
    actions = {event.get('action') for event in events
               if event.get('session') == session and event.get('returncode') == 0}
    if not {'resume', 'pause', 'stop'}.issubset(actions):
        raise RuntimeError('drain requires successful controls for the current stopped session')
    payload = json.loads((out/'profile-request.json').read_text())
    payload.update(max_tokens=1, stream=False)
    payload.pop('stream_options', None)
    put(out/'post-stop-drain-request.json', payload)
    pause = json.loads((out/'startup-registration-pause.json').read_text())
    if pause['returncode'] != 0:
        raise RuntimeError('drain requires successful registration pause')
    baseline = pause['trace_file_sizes']
    deadline = time.monotonic() + 600
    response = client.request('/v1/completions', payload, timeout_s=max(0.1, deadline-time.monotonic()))
    (out/'post-stop-drain-response.raw').write_bytes(response.body)
    result = json.loads(response.body)
    put(out/'post-stop-drain-response.json', result)
    usage = result.get('usage', {})
    choices = result.get('choices', [])
    if (response.status != 200 or usage.get('prompt_tokens') != 65_536
            or usage.get('completion_tokens') != 1 or not choices
            or choices[0].get('finish_reason') != 'length'):
        raise RuntimeError('post-stop drain response failed HTTP/token validation')
    valid = []; flush_lines = []
    while time.monotonic() < deadline:
        flush_lines = [line for line in (out/'server.log').read_text(errors='replace').splitlines()
                       if '[INFO] Flush profile data as the session is stopped' in line]
        valid = post_pause_gpu_traces(out, baseline)
        if flush_lines and valid:
            break
        time.sleep(min(0.5, max(0, deadline-time.monotonic())))
    record = {'http_status': response.status, 'usage': usage, 'session': session,
              'flush_acknowledgements': flush_lines, 'complete_activity_traces': valid,
              'post_pause_trace_file_sizes': baseline,
              'scope': 'new/larger post-pause GPU producer files only; drain not measured workload or whole-graph qualification'}
    put(out/'producer-flush-check.json', record)
    if not flush_lines or not valid:
        raise RuntimeError('producer flush not confirmed before forced owned cleanup')
    return record

def dispatch_512(phase0, out, name):
    """Use Phase0 launch/instrumentation and lifecycle, with only prompt metadata overridden in memory."""
    if not DRIVER.is_file(): raise RuntimeError(f'missing lifecycle driver: {DRIVER}')
    driver=runpy.run_path(str(DRIVER)); ns=driver['main'].__globals__
    ns.update(CAMPAIGN=phase0.ROOT.name, CONTEXT=212_992, BATCHED_TOKENS=8_192,
              PROMPT_TOKENS=65_536, cell_name=lambda _cell:name)
    base=phase0._configure_launch(ns, ns['build_launch'], 'unitrace-profile', None, UNITRACE)
    def build(cell, build_out, args):
        argv, meta=base(cell, build_out, args)
        meta['common_contract']['prompt_lengths']=[65_536]
        meta['diagnostic_contract']={'input_tokens':65_536,'output_tokens':128,
            'attribution':'fail-closed; valid trace and controls are necessary, not sufficient'}
        return argv, meta
    ns['build_launch']=build
    original_profile_request = ns['run_profile_request']
    def profile_then_drain(client, build_out, module, args):
        result = original_profile_request(client, build_out, module, args)
        drain_and_confirm(client, build_out, phase0.UNITRACE_SESSION)
        return result
    ns['run_profile_request'] = profile_then_drain
    original_wait = ns['wait_for_server']
    def registered_then_pause(proc, client, build_out, model, timeout_s):
        selected = original_wait(proc, client, build_out, model, timeout_s)
        warm = build_out/'startup-registration-warmup'; warm.mkdir()
        module = ns['resolve_prompt_module'](CLIENT)
        prompt, nonce = ns['render_profile_prompt'](client, warm, module)
        payload = module.completion_payload(model, prompt)
        payload.update(stream=False)
        payload.pop('stream_options', None)
        put(warm/'request.json', payload)
        response = client.request('/v1/completions', payload, timeout_s=600)
        (warm/'response.raw').write_bytes(response.body)
        result = json.loads(response.body); put(warm/'response.json', result)
        usage = result.get('usage', {}); choices = result.get('choices', [])
        if (response.status != 200 or usage.get('prompt_tokens') != 65_536
                or usage.get('completion_tokens') != 128 or not choices
                or choices[0].get('finish_reason') != 'length'):
            raise RuntimeError('startup registration warmup HTTP/token validation failed')
        argv = ['docker', 'exec', name, '/unitrace/bin/unitrace',
                '--pause', phase0.UNITRACE_SESSION]
        started = time.time_ns(); pause = cmd(argv, 60); finished = time.time_ns()
        trace_file_sizes = {str(path.relative_to(build_out)): path.stat().st_size
                            for path in (build_out/'unitrace').glob('*.json') if path.is_file()}
        put(build_out/'startup-registration-pause.json', {'argv': argv,
            'returncode': pause.returncode, 'stdout': pause.stdout,
            'started_unix_ns': started, 'finished_unix_ns': finished,
            'trace_file_sizes': trace_file_sizes, 'warmup_usage': usage, 'scope': 'startup/warmup registration only; exclude from measured replay'})
        if pause.returncode != 0:
            raise RuntimeError('pause after startup registration failed')
        return selected
    ns['wait_for_server'] = registered_then_pause
    remaining=['--startup-timeout','1800','--benchmark-timeout','600','--request-timeout','600',
               '--control-timeout','60','--long-client',str(CLIENT),
               '--profile','--profile-delay-iterations','3','--profile-max-iterations','5',
               '--profile-stop-after-events','512']
    sys.argv=[str(PHASE0),*remaining,'--cell','mtp4','--out',str(out)]
    status=int(driver['main']())
    artifact_status=capture_artifact_check(phase0,out)
    return status or artifact_status

def main():
    if len(sys.argv)!=2: raise SystemExit('usage: controller FRESH_OUTPUT_DIR')
    out=Path(sys.argv[1]).resolve()
    if out.exists(): raise RuntimeError(f'output must be fresh: {out}')
    out.mkdir(parents=True)
    name=f'b70qwen38unitrace{os.getpid()}{uuid.uuid4().hex[:10]}'
    session=f'b70gdnunitrace{os.getpid()}{uuid.uuid4().hex[:12]}'
    spec=importlib.util.spec_from_file_location('phase0',PHASE0)
    if spec is None or spec.loader is None: raise RuntimeError(f'cannot import {PHASE0}')
    phase0=importlib.util.module_from_spec(spec); spec.loader.exec_module(phase0)
    phase0.UNITRACE_SESSION=session; phase0._container_name=lambda _mode:name
    if '--start-paused' not in phase0.UNITRACE_OPTIONS:
        raise RuntimeError('unexpected phase0 options; registration override refused')
    phase0.UNITRACE_OPTIONS=tuple(x for x in phase0.UNITRACE_OPTIONS if x != '--start-paused')
    put(out/'controller-contract.json',{'phase0':str(PHASE0),'base_driver':str(DRIVER),'client':str(CLIENT),
        'unitrace_install':str(UNITRACE),'unitrace_source_commit':SRC_SHA,'input_tokens':65_536,'output_tokens':128,
        'unitrace_session':session,'container_name':name,'timeouts_s':{'startup':1800,'request':600,'control':60,'registration_warmup':600,'outer':4000},
        'controls':['resume','pause','stop','producer observation and complete flush before cleanup'],'post_stop_drain':{'input_tokens':65_536,'output_tokens':1,'timeout_s':600,'measured':False},'startup_registration':'collect startup and one65536->128warmup, pause before profiled request; startup/warmup excluded','scope':'predeclared 64K native MTP4 graph attribution; no performance or fusion claim'})
    pre=kernel(out,'pre')
    if any(x['error_lines'] for x in pre['commands'].values()): raise RuntimeError('guarded pre-kernel errors present')
    preconditions(out,name)
    status=1; failure=None; started=time.monotonic()
    try: status=dispatch_512(phase0,out/'native',name)
    except BaseException as e: failure={'type':type(e).__name__,'message':str(e)}; put(out/'controller-failure.json',failure)
    finally:
        post=kernel(out,'post')
        post_state=out/'post-state'; post_state.mkdir()
        preconditions(post_state,name)
        before={x for s in pre['commands'].values() for x in s['error_lines']}; after={x for s in post['commands'].values() for x in s['error_lines']}
        new=sorted(after-before); put(out/'kernel-post-check.json',{'status':'failed' if new else 'clear','new_guarded_error_lines':new})
        if new: status=1
    put(out/'controller-footer.json',{'status':status,'failure':failure,'elapsed_s':time.monotonic()-started,'output':str(out)})
    print(json.dumps({'status':status,'output':str(out),'container_name':name,'unitrace_session':session},sort_keys=True),flush=True)
    return status

if __name__=='__main__': raise SystemExit(main())
